#' Raw mass spectrum proteomics log abundance for 4 pairs of technical replicates.  
#' @format A data frame of 85 rows and 8 columns with missing peaks' abundance as NA.
#' 

'replicates'